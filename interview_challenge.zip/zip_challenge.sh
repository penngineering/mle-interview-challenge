zip -r interview_challenge.zip . -x "*.git*" -x "*.DS_Store" -x "*.idea*" -x "*.local*" -x "*.ipython*" -x "*.cache*" -x "*.ipynb_checkpoints*" -x "app/*" -x "notebooks/.npm/*"
