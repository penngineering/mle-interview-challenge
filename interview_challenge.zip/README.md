 # The Challenge

Sportsball wagering provides a great source of entertainment for people in the country of Bettorvania.

There are 16 teams in the Major Sportsball League and they are spread across 12 provinces. We currently provide wagering services for 4 of those provinces: Regensland, Alterburg, Vistatown, and Boroughsville.

Our newest data scientist Dr Research, straight out of the world of academia, has delivered a model which can predict the number of dollars wagered (a.k.a. "handle") on the matches. They have provided a notebook in `notebooks/handle_forecast_basic_solution.ipynb`. This notebook contains both a SQL feature-pull from the provided DB, as well as all modelling code.

It is known that the enterprise DB only refreshes daily. Conveniently, someone from the data services team has created an API that contains up-to-date data around the sportsball matches for the upcoming week (For the sake of this project, the "upcoming" week is week 11 of the 2020 season).

The finance team has asked to be able to retrieve the most up-to-date forecast on-demand.

Your mission, should you choose to accept, is to create what you would define as a deployment for this model. This problem is simplified for the sake of time but is representative of actual project work that we do here at Penn Interactive/TheScore Bet.

Please do not spend more than 5 hours on this challenge. Don't let this take up your whole weekend. We understand that you could likely spend days on this, but we are more interested in seeing your thought process than a fully formed deployment. If you find yourself getting close to time, focus on providing insights into your thoughts in the write-up portion.

### Requirements

To complete this challenge, you will need docker and docker-compose installed on your computer.

If you do not already have these tools, we recommend using Docker Desktop:

* Mac: https://docs.docker.com/desktop/install/mac-install/
* Windows: https://docs.docker.com/desktop/install/windows-install/
* Linux: https://docs.docker.com/desktop/install/linux-install/

# Setup

We've provided a `docker-compose.yml` file which will create everything you need to complete this challenge. To setup your environment, simply navigate in your Command Prompt/Terminal to the directory where you unpacked these files and run `docker-compose up -d`. This may take a minute to finish running, especially if it's your first time running it.

## The Database

After `docker-compose up -d` has finished, you will have access to a Postgres Database and PGAdmin to play around with the data. To access PGAdmin, navigate to `localhost:5050` in your web browser. From here, you will need to configure a connection to the the server. You can do this by selecting "Add New Server" from the dashboard.sa

Connection Details:

* host: `local_pg`
* port: `5432`
* user: `postgres`
* password `postgres`

The database has 3 tables:

### `events` (`SELECT * FROM events`) - Data for the Sportsball events

| Column Name            | Data Type | Description                            |
|------------------------|-----------|----------------------------------------|
| event_id (primary_key) | VARCHAR   | Unique id given to the event           |
| home_team              | VARCHAR   | The home team for the event            |
| away_team              | VARCHAR   | The away team for the event            |
| home_team_location     | VARCHAR   | Base city for the home team            |
| away_team_location     | VARCHAR   | Base city for the away team            |
| day_of_week            | VARCHAR   | day of the week ('Sunday' etc)         |
| time_slot              | VARCHAR   | Categorical indicating time/day grouping     |
| game_day               | TIMESTAMP | Game date (EST)                              |
| game_start_time        | TIMESTAMP | Start time of the event (EST)          |
| week_start             | TIMESTAMP | Start time for this week of the season (EST) |
| week_of_season         | FLOAT     | Week number of the season              |

### `users` (`SELECT * FROM users`) - User demographic data

| Column Name               | Data Type | Description                                 |
|---------------------------|-----------|---------------------------------------------|
| user_number (primary_key) | VARCHAR   | Unique identifier for the user              |
| age                       | FLOAT     | User age in years                           |
| registration_timestamp    | TIMESTAMP | Datetime the user registered for the sportsbook (EST)|
| location                  | VARCHAR   | Where the user resides                      |

### `wagers` (`SELECT * FROM wagers`) - Data on the individual wagers placed on Sportsball games

| Column Name           | Data Type | Description                             | Additional Resources                                                                                                                                                                                |
|-----------------------|-----------|-----------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| bet_id (primary_key)  | INTEGER   | Unique identifier for the bet            |
| user_number           | VARCHAR   | Unique identifier for the user           |                                                                                                                                             |
| event_id              | VARCHAR   | Event the bet was placed on             |                                                                                                                                                                                                     |
| bet_offer_type_name   | VARCHAR   | Describes the type of bet placed        | https://www.actionnetwork.com/education/point-spread (Spread)  https://www.actionnetwork.com/education/over-under-total (Over/Under)  https://www.actionnetwork.com/education/moneyline (Outright) |
| wager_amount          | FLOAT     | Amount in USD bet                       |                                                                                                                                                                                                     |
| outcome_decimal_odds  | FLOAT     | The odds of the bet in decimal format   | https://www.actionnetwork.com/education/decimal-odds                                                                                                                                                |
| outcome_american_odds | FLOAT     | The odds of the bet in american format  | https://www.actionnetwork.com/education/american-odds#Read                                                                                                                                          |
| bet_placed_time       | TIMESTAMP | Time the bet was placed (EST)           |                                                                                                                                                                                                     |
| bet_status            | VARCHAR   | Whether or not the bet has settled      |                                                                                                                                                                                                     |
| bet_result            | VARCHAR   | Outcome of the bet                      |                                                                                                                                                                                                     |
| payout                | FLOAT     | Payout amount in USD if the bet was won |                                                                                                                                                                                                     |

## Jupyter Server

The compose file also creates a Jupyter Server instance for you to use. You can access it by navigating to `localhost:8888?token=sports` in your web browser.

# Challenge Structure

## Code

For this challenge, you are allowed to change any existing files or add new files as you see fit. This includes the provided jupyter notebook. The only files that must remain unaltered are the csv files in the `data` directory.

Unlike the Data Scientist version of this challenge, the MLE version is far more open ended. A big part of the evaluation will be how you chose to interpret the problem, and how you handle the loose requirements.

## Technical Write-up

When we say dont take too long on this, we really mean it. There are all sorts of soft-skills we look for beyond technical skills, and time management is definitely one of them.

Provide us with a write-up (in whatever format you choose) that quickly outlines your provide solution. In addition, use this as an opportunity to propose extra features/improvements you would have made provided you had more time.

(Hint: "I would monitor the model outputs" is cool, but we'd like to know how.)

# Submission

When you have completed the challenge, re-zip this project as `<your_name>_interview_challenge.zip` and send it back to the recruiter.
